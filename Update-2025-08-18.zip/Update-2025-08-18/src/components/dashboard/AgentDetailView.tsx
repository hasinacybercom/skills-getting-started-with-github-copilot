import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCompany } from '../../hooks/useSupabase';
import { 
  ArrowLeft,
  MessageSquare, 
  Send, 
  Paperclip, 
  Mic, 
  MoreHorizontal,
  Star,
  Clock,
  TrendingUp,
  Users,
  Phone,
  Mail,
  Settings,
  Play,
  Pause,
  Volume2,
  VolumeX,
  BarChart3,
  Target,
  Heart,
  Zap,
  Bot,
  Crown,
  Shield,
  Award,
  CheckCircle,
  Calendar,
  FileText,
  Search,
  Eye,
  Edit,
  Globe,
  Smartphone,
  Headphones,
  Calculator,
  Scale,
  Briefcase,
  Code,
  HelpCircle,
  Wrench,
  Image,
  Scissors,
  PenTool,
  Workflow,
  Bug,
  BookOpen,
  MessageCircle,
  Database,
  Save,
  Upload,
  Download,
  Trash2,
  Filter,
  ChevronDown,
  Info,
  AlertTriangle,
  Activity,
  Brain,
  Palette,
  Timer,
  Sparkles
} from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import AgentDetailHeader from './AgentDetailHeader';
import AgentDetailTabs from './AgentDetailTabs';
import { MessageBubble } from './MessageBubble';

interface AgentDetailViewProps {
  agentId: string;
  onBack: () => void;
}

const AgentDetailView: React.FC<AgentDetailViewProps> = ({ agentId, onBack }) => {
  const navigate = useNavigate();
  const { company } = useCompany();
  const [message, setMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isWebhookCalled, setIsWebhookCalled] = useState(false);
  const [activeTab, setActiveTab] = useState('chat');
  const [conversationId, setConversationId] = useState(uuidv4());
  const [chatHistory, setChatHistory] = useState([
    {
      agent_id: agentId,
      sender_type: 'agent',
      content: "Salut ! Je suis votre assistant IA. Comment puis-je vous aider aujourd'hui ?",
      timestamp: new Date().toLocaleString()
    }
  ]);
  const [conversationHistory, setConversationHistory] = useState([
    {
      id: 'conv_001',
      title: 'Configuration du chatbot commercial',
      date: '2025-01-15 14:30',
      duration: '25 min',
      messageCount: 18,
      lastMessage: 'Parfait ! Le chatbot est maintenant configuré.',
      preview: 'Discussion sur la mise en place du chatbot commercial pour le site web...',
      status: 'completed'
    },
    {
      id: 'conv_002',
      title: 'Optimisation du script de vente',
      date: '2025-01-14 10:15',
      duration: '35 min',
      messageCount: 24,
      lastMessage: 'Les scripts sont prêts à être utilisés.',
      preview: 'Amélioration des scripts de vente pour augmenter le taux de conversion...',
      status: 'completed'
    },
    {
      id: 'conv_003',
      title: 'Analyse des retours clients',
      date: '2025-01-13 16:45',
      duration: '15 min',
      messageCount: 12,
      lastMessage: 'Voici le rapport d\'analyse des feedbacks.',
      preview: 'Analyse approfondie des retours clients pour améliorer le service...',
      status: 'completed'
    }
  ]);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const messageInputRef = useRef<HTMLInputElement>(null);
  const cccAgentIds = {
      "elise": "5b26fb54-1ded-4d4f-8c45-4a27f716ce2d", //Elise SEO
      "margot": "662026df-aee4-4137-a34c-3298bec8282c", // Margot -> Michael
      "john": "f7f5ff2d-151a-4291-a4aa-ede5258ee1af", // JHON
      "ia-juriste": "ff0ab381-2506-464f-a411-5be26115efbf" // Legal IA
    };
  const listedAgents = ["5b26fb54-1ded-4d4f-8c45-4a27f716ce2d","662026df-aee4-4137-a34c-3298bec8282c","f7f5ff2d-151a-4291-a4aa-ede5258ee1af","ff0ab381-2506-464f-a411-5be26115efbf"];

  const getAgentResponse = (agentName: string, userMessage: string) => {
    const responses = {
      'Mickael': [
        "Je comprends votre demande. Laissez-moi vous aider à résoudre ce problème étape par étape.",
        "Parfait ! Je vais analyser votre situation et vous proposer la meilleure solution.",
        "C'est une excellente question. Voici comment nous pouvons procéder..."
      ],
      'Lou': [
        "Super question SEO ! Voici comment optimiser ça pour le référencement...",
        "J'ai des idées géniales pour booster votre visibilité sur ce point !",
        "Analysons ensemble votre stratégie de contenu pour maximiser l'impact..."
      ],
      'Elio': [
        "Excellent prospect à cibler ! Voici ma stratégie de prospection pour ce cas...",
        "Je vois du potentiel ici. Laissez-moi vous préparer une approche commerciale efficace.",
        "Parfait pour une campagne de prospection. Voici comment procéder..."
      ],
      'John': [
        "Génial ! J'ai plein d'idées créatives pour votre campagne marketing...",
        "C'est exactement le type de contenu qui peut devenir viral ! Voici mon plan...",
        "Parfait timing pour une stratégie marketing. Voici ce que je propose..."
      ],
      'Charly': [
        "Ok ! Je vais organiser ça pour vous de manière optimale...",
        "Très bien, laissez-moi structurer cette tâche pour maximiser votre efficacité.",
        "Je m'occupe de tout ! Voici comment je vais organiser cela..."
      ],
      'Tessa': [
        "Excellente question juridique. Voici les éléments à considérer...",
        "D'un point de vue légal, voici ce que je recommande...",
        "Je vais analyser cette situation juridique et vous donner mes conseils..."
      ]
    };
    
    const agentResponses = responses[agentName as keyof typeof responses] || responses['Mickael'];
    return agentResponses[Math.floor(Math.random() * agentResponses.length)];
  };

  const handleSendMessage = async () => {
    
    console.log("CompanyId- "+company.id);
    console.log("Agent: "+agentId+" :ID- "+cccAgentIds[agentId]);
    console.log("ConversatioNid - "+conversationId);
    console.log('handle send Message rom agent detail view');
    if (!message.trim()) return;

    if(chatHistory.length == 1)
    {
        let logMessageId = uuidv4();
        const userMessage = {
          id: logMessageId,
          company_id: company.id,
          agent_id: cccAgentIds[agentId],
          conversation_id: conversationId,
          sender_type: 'agent',
          content: chatHistory[0].content,
          created_at: new Date().toLocaleString()
        };

        setChatHistory([userMessage]);
    }
    
    let logMessageId = uuidv4();
    const userMessage = {
     id: logMessageId,
      company_id: company.id,
      agent_id: cccAgentIds[agentId],
      conversation_id: conversationId,
      sender_type: 'company',
      content: message,
      created_at: new Date().toLocaleString()
    };
    
    setChatHistory(prev => [...prev, userMessage]);
    setMessage('');
    setIsTyping(true);
    
    // Simulation de réponse de l'agent
    if(listedAgents.includes(cccAgentIds[agentId])){
        
        setTimeout(async () => {
        try {
            let webhookurl = 'https://n8n.ozzygo.live/webhook/agent-'+agentId;
            console.log(webhookurl);
            
            const res = await fetch(webhookurl, {
            method: 'post',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message: message,
                logMessageId: logMessageId,
                logMissionId: conversationId,
                company_id: company.id,
                agent_id: cccAgentIds[agentId],
                sender_type: 'company'
            })
            });

            if (!res.ok) {
              throw new Error(`Webhook error: ${res.status}`);
            }

            // Check if response is binary (image/video)
            const contentType = res.headers.get('content-type') || '';
            let agentResponse: Message;

            if (contentType.startsWith('image/') || contentType.startsWith('video/')) {
              // Handle binary media response
              const blob = await res.blob();
              const mediaUrl = URL.createObjectURL(blob);
              const mediaType = contentType.startsWith('image/') ? 'image' : 'video';
              
              agentResponse = {
                  id: uuidv4(),
                  company_id: company.id,
                  agent_id: cccAgentIds[agentId],
                  conversation_id: conversationId,
                  sender_type: 'agent',
                  content: mediaType === 'image' ? 'Here\'s an image for you:' : 'Here\'s a video for you:',
                  media_type: mediaType,
                  media_url: mediaUrl,
                  created_at: new Date().toISOString(),
              };
            } else if (contentType.includes('text/html')) {
              // Handle HTML response
              const htmlContent = await res.text();
              agentResponse = {
                  id: uuidv4(),
                  company_id: company.id,
                  agent_id: cccAgentIds[agentId],
                  conversation_id: conversationId,
                  sender_type: 'agent',
                  content: htmlContent,
                  media_type: 'html',
                  created_at: new Date().toISOString(),
              };  
            } else {
              // Handle JSON text response
              const data = await res.json();
              agentResponse = {
                  id: uuidv4(),
                  company_id: company.id,
                  agent_id: cccAgentIds[agentId],
                  conversation_id: conversationId,
                  sender_type: 'agent',
                  content: data.message || 'No reply from webhook',
                  media_type: 'text',
                  created_at: new Date().toISOString(),
              };
            }

            setChatHistory(prev => [...prev, agentResponse]);
        } catch (err) {
            console.error('Webhook call failed:', err);
            setChatHistory(prev => [
            ...prev,
            {
                id: uuidv4(),
                company_id: company.id,
                agent_id: cccAgentIds[agentId],
                conversation_id: conversationId,
                sender_type: 'agent',
                content: 'Sorry, I could not get a response.',
                media_type: 'text',
                created_at: new Date().toISOString(),
            },
            ]);
        } finally {
          setIsWebhookCalled(true);
            setIsTyping(false);
            console.log('chat Over');
        }
        }, 100);
    }
    else{
        setTimeout(() => {
          const agentResponse = {
            sender_type: 'agent' as const,
            content: getAgentResponse(currentAgent.name, message),
            timestamp: new Date().toLocaleTimeString()
          };
          setChatHistory(prev => [...prev, agentResponse]);
          setIsTyping(false);
        }, 1500);
    }
  };

  console.log(isWebhookCalled);
if(isWebhookCalled && listedAgents.includes(cccAgentIds[agentId])){
  console.log("outsidechatHistoyrLenntgh : "+chatHistory.length);
  console.log(chatHistory);
  setIsWebhookCalled(false);
  if(chatHistory.length > 1)
  {
      const res = fetch('https://n8n.ozzygo.live/webhook/save-agent-conversation', {
          method: 'post',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
          conversation: chatHistory
          })
      });
  }
}

  // Données complètes des agents
  const agentsData = {
    mickael: {
      id: 'mickael',
      name: 'Mickael',
      role: 'Assistant Relation Client',
      avatar: 'https://i.postimg.cc/ZnxLBN3X/mickael.png',
      color: 'from-blue-500 to-cyan-500',
      emoji: '💬',
      description: 'Spécialiste du support client avec une approche empathique et efficace. Mickael gère tous vos échanges clients avec professionnalisme.',
      greeting: "Salut ! Je suis Mickael, ton assistant relation client. Comment puis-je t'aider aujourd'hui ?",
      stats: {
        conversations: 2847,
        satisfaction: 4.9,
        responseTime: '1.2s',
        resolutionRate: '94%'
      },
      powerUps: [
        {
          id: 'chatbot',
          title: 'Chatbot Commercial',
          description: 'Assistant commercial personnalisé pour votre site.',
          icon: MessageSquare,
          available: true
        },
        {
          id: 'call-analysis',
          title: 'Analyse de call',
          description: 'Analyse des appels avec rapport et points d\'amélioration.',
          icon: Phone,
          available: true
        },
        {
          id: 'process-notion',
          title: 'Process Notion',
          description: 'Process Notion personnalisés pour votre entreprise.',
          icon: Database,
          available: false
        },
        {
          id: 'sales-script',
          title: 'Script de vente',
          description: 'Scripts de vente optimisés pour votre activité.',
          icon: FileText,
          available: true
        }
      ],
      channels: ['phone', 'chat', 'email', 'whatsapp'],
      languages: ['Français', 'Anglais'],
      specialty: 'Support client 24/7 avec escalade intelligente'
    },
    lou: {
      id: 'lou',
      name: 'Lou',
      role: 'Assistante SEO',
      avatar: 'https://i.postimg.cc/DwjBP1DT/lou.png',
      color: 'from-green-500 to-emerald-500',
      emoji: '🔍',
      description: 'Experte SEO qui optimise votre visibilité en ligne avec des stratégies de référencement avancées.',
      greeting: "Salut ! Je suis Lou, ton assistante SEO. Prêt à booster ton référencement ?",
      stats: {
        conversations: 1923,
        satisfaction: 4.8,
        responseTime: '0.9s',
        resolutionRate: '91%'
      },
      powerUps: [
        {
          id: 'seo-audit',
          title: 'Audit SEO',
          description: 'Analyse complète de votre site web.',
          icon: Search,
          available: true
        },
        {
          id: 'keyword-research',
          title: 'Recherche de mots-clés',
          description: 'Identification des meilleurs mots-clés pour votre secteur.',
          icon: Target,
          available: true
        },
        {
          id: 'content-optimization',
          title: 'Optimisation de contenu',
          description: 'Amélioration de vos contenus pour le SEO.',
          icon: Edit,
          available: true
        }
      ],
      channels: ['chat', 'email'],
      languages: ['Français', 'Anglais'],
      specialty: 'Référencement naturel et stratégie de contenu'
    },
    elio: {
      id: 'elio',
      name: 'Elio',
      role: 'Assistant Commercial',
      avatar: 'https://i.postimg.cc/KzwYDjdP/elio.png',
      color: 'from-orange-500 to-red-500',
      emoji: '🎯',
      description: 'Expert en prospection et développement commercial. Elio vous aide à identifier et convertir vos prospects.',
      greeting: "Salut ! Je suis Elio, ton assistant commercial. Prêt à booster tes ventes ?",
      stats: {
        conversations: 3156,
        satisfaction: 4.9,
        responseTime: '1.1s',
        resolutionRate: '96%'
      },
      powerUps: [
        {
          id: 'lead-generation',
          title: 'Génération de leads',
          description: 'Identification et qualification de prospects.',
          icon: Users,
          available: true
        },
        {
          id: 'sales-funnel',
          title: 'Tunnel de vente',
          description: 'Création de tunnels de conversion optimisés.',
          icon: TrendingUp,
          available: true
        }
      ],
      channels: ['phone', 'chat', 'email', 'whatsapp'],
      languages: ['Français', 'Anglais', 'Espagnol'],
      specialty: 'Prospection B2B et closing commercial'
    },
    john: {
      id: 'john',
      name: 'John',
      role: 'Assistant Marketing',
      avatar: 'https://i.postimg.cc/zGXxhxx7/john.png',
      color: 'from-purple-500 to-pink-500',
      emoji: '🚀',
      description: 'Créatif marketing qui développe des campagnes innovantes pour faire grandir votre marque.',
      greeting: "Hey ! Je suis John, ton assistant marketing créatif. On va faire du bruit ensemble !",
      stats: {
        conversations: 2341,
        satisfaction: 4.7,
        responseTime: '1.3s',
        resolutionRate: '89%'
      },
      powerUps: [
        {
          id: 'campaign-creation',
          title: 'Création de campagnes',
          description: 'Développement de campagnes marketing créatives.',
          icon: Zap,
          available: true
        },
        {
          id: 'social-media',
          title: 'Réseaux sociaux',
          description: 'Gestion et optimisation de vos réseaux sociaux.',
          icon: Heart,
          available: true
        },
        {
          id: 'content-planner',
          title: 'Planificateur de contenu',
          description: 'Planificateur de contenu multicanal',
          icon: Calendar,
          available: true
        },
        {
          id: 'post-generator',
          title: 'Générateur de posts',
          description: 'Générateur de posts LinkedIn / Instagram / X',
          icon: PenTool,
          available: true
        },
        {
          id: 'hook-generator',
          title: 'Générateur de hooks',
          description: 'Générateur de hooks & slogans personnalisés',
          icon: Target,
          available: true
        },
        {
          id: 'performance-analysis',
          title: 'Analyse de performance',
          description: 'Analyse de performance (engagements, CTR…)',
          icon: TrendingUp,
          available: true
        },
        {
          id: 'visual-generator',
          title: 'Générateur de visuels',
          description: 'Générateur de visuels (IA DALL·E / Pollinations)',
          icon: Palette,
          available: true
        }
      ],
      channels: ['chat', 'email'],
      languages: ['Français', 'Anglais'],
      specialty: 'Marketing digital et création de contenu'
    },
    charly: {
      id: 'charly',
      name: 'Charly',
      role: 'Assistant Organisation',
      avatar: 'https://i.postimg.cc/wBn2Sgg4/charly.png',
      color: 'from-teal-500 to-blue-500',
      emoji: '📋',
      description: 'Maître de l\'organisation qui structure vos processus et optimise votre productivité.',
      greeting: "Salut ! Je suis Charly, ton assistant organisation. Prêt à tout organiser ?",
      stats: {
        conversations: 1876,
        satisfaction: 4.8,
        responseTime: '0.8s',
        resolutionRate: '93%'
      },
      powerUps: [
        {
          id: 'task-management',
          title: 'Gestion des tâches',
          description: 'Organisation et suivi de vos projets.',
          icon: CheckCircle,
          available: true
        },
        {
          id: 'process-optimization',
          title: 'Optimisation des processus',
          description: 'Amélioration de vos workflows.',
          icon: Workflow,
          available: true
        }
      ],
      channels: ['chat', 'email'],
      languages: ['Français', 'Anglais'],
      specialty: 'Productivité et gestion de projet'
    },
    tessa: {
      id: 'tessa',
      name: 'Tessa',
      role: 'Assistante Juridique',
      avatar: 'https://i.postimg.cc/yNqsrvP3/tessa.png',
      color: 'from-indigo-500 to-purple-500',
      emoji: '⚖️',
      description: 'Experte juridique qui vous accompagne dans vos démarches légales et contractuelles.',
      greeting: "Bonjour ! Je suis Tessa, votre assistante juridique. Comment puis-je vous conseiller ?",
      stats: {
        conversations: 1234,
        satisfaction: 4.9,
        responseTime: '1.5s',
        resolutionRate: '97%'
      },
      powerUps: [
        {
          id: 'contract-review',
          title: 'Révision de contrats',
          description: 'Analyse et révision de vos contrats.',
          icon: FileText,
          available: true
        },
        {
          id: 'legal-advice',
          title: 'Conseil juridique',
          description: 'Conseils juridiques personnalisés.',
          icon: Scale,
          available: true
        }
      ],
      channels: ['chat', 'email'],
      languages: ['Français', 'Anglais'],
      specialty: 'Droit des affaires et conseil juridique'
    }
  };

  const currentAgent = agentsData[agentId as keyof typeof agentsData] || agentsData.mickael;

  const handleResumeConversation = (conversationId: string) => {
    console.log('Resuming conversation:', conversationId);
    setActiveTab('chat');
  };

  const handleUsePowerUp = (powerUpId: string) => {
    // Navigation vers l'interface spécialisée selon l'agent et le power-up
    if (currentAgent.name === 'John' && (
      powerUpId === 'social-media' || 
      powerUpId === 'campaign-creation' ||
      powerUpId === 'content-planner' ||
      powerUpId === 'post-generator'
    )) {
      navigate('/john-marketing');
    } else {
      console.log('Utilisation du power-up:', powerUpId);
    }
  };

  const getChannelIcon = (channel: string) => {
    switch (channel) {
      case 'phone': return <Phone className="w-4 h-4 text-green-400" />;
      case 'chat': return <MessageSquare className="w-4 h-4 text-blue-400" />;
      case 'email': return <Mail className="w-4 h-4 text-red-400" />;
      case 'whatsapp': return <Smartphone className="w-4 h-4 text-green-500" />;
      default: return <MessageSquare className="w-4 h-4 text-gray-400" />;
    }
  };

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory, isTyping]);

  const renderTabContent = () => {
    switch (activeTab) {
      case 'chat':
        return (
          <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Agent Info Sidebar */}
            <div className="space-y-6">
              {/* Agent Card */}
              <div className="relative bg-slate-800/40 backdrop-blur-xl rounded-3xl border border-slate-700/50 p-8 shadow-2xl overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-slate-700/20 via-transparent to-slate-600/20 rounded-3xl" />
                <div className={`absolute inset-0 bg-gradient-to-br ${currentAgent.color} opacity-10 rounded-3xl`} />
                
                <div className="relative z-10 text-center">
                  <div className="w-32 h-32 mx-auto mb-6 bg-white/10 backdrop-blur-xl rounded-full border border-white/20 overflow-hidden shadow-2xl">
                    <img 
                      src={currentAgent.avatar} 
                      alt={currentAgent.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  <h2 className="text-2xl font-bold text-white mb-2">{currentAgent.name}</h2>
                  <p className="text-blue-400 font-medium mb-4">{currentAgent.role}</p>
                  <p className="text-white/70 text-sm leading-relaxed">{currentAgent.description}</p>
                </div>
              </div>

              {/* Stats */}
              <div className="relative bg-slate-800/40 backdrop-blur-xl rounded-3xl border border-slate-700/50 p-6 shadow-2xl overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-slate-700/20 via-transparent to-slate-600/20 rounded-3xl" />
                
                <div className="relative z-10">
                  <h3 className="text-lg font-bold text-white mb-4 flex items-center">
                    <BarChart3 className="w-5 h-5 mr-2 text-blue-400" />
                    Performances
                  </h3>
                  
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-white/70">Conversations</span>
                      <span className="text-white font-bold">{currentAgent.stats.conversations.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-white/70">Satisfaction</span>
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                        <span className="text-white font-bold">{currentAgent.stats.satisfaction}/5</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-white/70">Temps de réponse</span>
                      <span className="text-white font-bold">{currentAgent.stats.responseTime}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-white/70">Résolution</span>
                      <span className="text-white font-bold">{currentAgent.stats.resolutionRate}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Channels */}
              <div className="relative bg-slate-800/40 backdrop-blur-xl rounded-3xl border border-slate-700/50 p-6 shadow-2xl overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-slate-700/20 via-transparent to-slate-600/20 rounded-3xl" />
                
                <div className="relative z-10">
                  <h3 className="text-lg font-bold text-white mb-4 flex items-center">
                    <Globe className="w-5 h-5 mr-2 text-green-400" />
                    Canaux actifs
                  </h3>
                  
                  <div className="grid grid-cols-2 gap-3">
                    {currentAgent.channels.map((channel, index) => (
                      <div key={index} className="flex items-center space-x-2 p-3 bg-white/10 backdrop-blur-xl rounded-xl border border-white/20">
                        {getChannelIcon(channel)}
                        <span className="text-white/80 text-sm capitalize">{channel}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Chat Area */}
            <div className="lg:col-span-2">
              <div className="relative bg-slate-800/40 backdrop-blur-xl rounded-3xl border border-slate-700/50 shadow-2xl overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-slate-700/20 via-transparent to-slate-600/20 rounded-3xl" />
                
                <div className="relative z-10 h-[600px] flex flex-col">
                  {/* Chat Header */}
                  <div className="p-6 border-b border-slate-700/50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="text-2xl">{currentAgent.emoji}</div>
                        <div>
                          <h3 className="text-xl font-bold text-white">Discussion avec {currentAgent.name}</h3>
                          <p className="text-white/60 text-sm">Assistant IA spécialisé</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button className="p-2 bg-white/10 hover:bg-white/20 rounded-xl transition-colors">
                          <Volume2 className="w-5 h-5 text-white/80" />
                        </button>
                        <button className="p-2 bg-white/10 hover:bg-white/20 rounded-xl transition-colors">
                          <MoreHorizontal className="w-5 h-5 text-white/80" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Messages */}
                  <div className="flex-1 overflow-y-auto p-6 space-y-4">
                    {chatHistory.map((msg, index) => (
                      <MessageBubble
                        key={index}
                        message={msg}
                        isAgent={msg.sender_type === 'agent'}
                        currentAgentAvatar={currentAgent.avatar}
                        currentAgentName={currentAgent.name}
                      />
                    ))}
                    
                    {isTyping && (
                      <div className="flex justify-start">
                        <div className="w-10 h-10 bg-white/10 backdrop-blur-xl rounded-full border border-white/20 overflow-hidden mr-3">
                          <img 
                            src={currentAgent.avatar} 
                            alt={currentAgent.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="bg-white/10 backdrop-blur-xl rounded-3xl rounded-tl-lg p-4 border border-white/20">
                          <div className="flex space-x-2">
                            <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce" />
                            <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                            <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
                          </div>
                        </div>
                      </div>
                    )}
                    
                    <div ref={chatEndRef} />
                  </div>

                  {/* Input */}
                  <div className="p-6 border-t border-slate-700/50">
                    <div className="flex items-center space-x-4">
                      <button className="p-3 bg-slate-700/50 hover:bg-slate-600/50 rounded-2xl transition-all duration-300 hover:scale-110">
                        <Paperclip className="w-5 h-5 text-white/80" />
                      </button>
                      <input
                        ref={messageInputRef}
                        type="text"
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        placeholder={`Discuter avec ${currentAgent.name}...`}
                        className="flex-1 px-6 py-4 bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl focus:border-white/40 focus:outline-none text-white placeholder-white/60 transition-all duration-300"
                        onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      />
                      <button className="p-3 bg-slate-700/50 hover:bg-slate-600/50 rounded-2xl transition-all duration-300 hover:scale-110">
                        <Mic className="w-5 h-5 text-white/80" />
                      </button>
                      <button 
                        onClick={handleSendMessage}
                        className="p-4 bg-blue-500 hover:bg-blue-600 rounded-2xl transition-all duration-300 hover:scale-110 shadow-lg hover:shadow-blue-500/25"
                      >
                        <Send className="w-5 h-5 text-white" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'history':
        return (
          <div className="max-w-6xl mx-auto">
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-white mb-4 flex items-center">
                <Clock className="w-8 h-8 mr-3 text-purple-400" />
                Historique des Conversations avec {currentAgent.name}
              </h2>
              <p className="text-white/70 text-lg">
                Retrouvez toutes vos discussions passées et reprenez là où vous vous êtes arrêtés
              </p>
            </div>

            {/* Search and Filters */}
            <div className="relative bg-slate-800/40 backdrop-blur-xl rounded-3xl border border-slate-700/50 p-6 shadow-2xl overflow-hidden mb-8">
              <div className="absolute inset-0 bg-gradient-to-br from-slate-700/20 via-transparent to-slate-600/20 rounded-3xl" />
              
              <div className="relative z-10">
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/40 w-6 h-6" />
                  <input
                    type="text"
                    placeholder="Rechercher dans vos conversations..."
                    className="w-full pl-14 pr-6 py-4 bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl focus:border-white/40 focus:outline-none text-white placeholder-white/60 transition-all duration-300 text-lg"
                  />
                </div>
              </div>
            </div>

            {/* Conversation History */}
            <div className="space-y-6">
              {conversationHistory.map((conversation) => (
                <div
                  key={conversation.id}
                  className="group relative overflow-hidden transition-all duration-700 hover:scale-105"
                >
                  <div className="relative bg-slate-800/40 backdrop-blur-xl rounded-3xl border border-slate-700/50 hover:border-slate-600/50 transition-all duration-700 shadow-2xl hover:shadow-4xl overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-slate-700/20 via-transparent to-slate-600/20 rounded-3xl" />
                    
                    <div className="relative z-10 p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-green-500/20 backdrop-blur-xl rounded-2xl border border-green-500/30 flex items-center justify-center">
                            <MessageSquare className="w-6 h-6 text-green-400" />
                          </div>
                          <div>
                            <h3 className="text-xl font-bold text-white group-hover:text-blue-100 transition-colors">
                              {conversation.title}
                            </h3>
                            <div className="flex items-center space-x-4 text-sm text-white/60">
                              <div className="flex items-center space-x-1">
                                <Calendar className="w-4 h-4" />
                                <span>{conversation.date}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <Clock className="w-4 h-4" />
                                <span>{conversation.duration}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <MessageSquare className="w-4 h-4" />
                                <span>{conversation.messageCount} messages</span>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <button
                          onClick={() => handleResumeConversation(conversation.id)}
                          className="group/btn relative overflow-hidden flex items-center space-x-2 px-6 py-3 bg-blue-500/80 text-white rounded-2xl hover:bg-blue-500 transition-all duration-500 hover:scale-105 font-medium backdrop-blur-xl border border-blue-500/30 shadow-lg hover:shadow-blue-500/25"
                        >
                          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover/btn:translate-x-full transition-transform duration-1000" />
                          <div className="relative z-10 flex items-center space-x-2">
                            <Play className="w-4 h-4" />
                            <span>Reprendre</span>
                          </div>
                        </button>
                      </div>

                      <div className="relative bg-white/5 backdrop-blur-xl rounded-2xl p-4 border border-white/10">
                        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-transparent rounded-2xl" />
                        <div className="relative z-10">
                          <p className="text-white/80 italic">"{conversation.lastMessage}"</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 'powerups':
        return (
          <div className="max-w-6xl mx-auto">
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-white mb-4 flex items-center">
                <Zap className="w-8 h-8 mr-3 text-yellow-400" />
                Boost IA de {currentAgent.name}
              </h2>
              <p className="text-white/70 text-lg">
                Découvrez toutes les capacités spécialisées de votre agent
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {currentAgent.powerUps.map((powerUp: any) => (
                <div
                  key={powerUp.id}
                  className={`group relative p-6 bg-slate-800/40 backdrop-blur-xl rounded-3xl border border-slate-700/50 hover:border-slate-600/50 transition-all duration-700 hover:scale-105 shadow-2xl hover:shadow-4xl overflow-hidden ${
                    !powerUp.available ? 'opacity-60' : ''
                  }`}
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-slate-700/20 via-transparent to-slate-600/20 rounded-3xl" />
                  <div className={`absolute inset-0 bg-gradient-to-br ${currentAgent.color} opacity-10 group-hover:opacity-20 transition-opacity duration-700 rounded-3xl`} />
                  
                  {powerUp.available && (
                    <div className="absolute top-4 right-4">
                      <div className="px-3 py-1 bg-blue-500/20 text-blue-300 text-xs rounded-full border border-blue-500/30 font-medium backdrop-blur-xl">
                        Disponible
                      </div>
                    </div>
                  )}

                  <div className="relative z-10">
                    <div className="w-12 h-12 bg-white/10 backdrop-blur-xl rounded-2xl flex items-center justify-center group-hover:bg-white/20 transition-all duration-500 border border-white/20 shadow-lg mb-4">
                      <powerUp.icon className="w-6 h-6 text-white/80" />
                    </div>
                    
                    <h3 className="text-xl font-bold text-white group-hover:text-blue-100 transition-colors mb-3">
                      {powerUp.title}
                    </h3>
                    <p className="text-white/70 text-sm leading-relaxed mb-4">
                      {powerUp.description}
                    </p>
                    
                    <button 
                      className={`w-full py-3 px-6 rounded-2xl font-medium transition-all duration-500 ${
                        powerUp.available
                          ? 'bg-blue-500/80 hover:bg-blue-500 text-white shadow-lg hover:shadow-blue-500/25'
                          : 'bg-slate-600/50 text-slate-400 cursor-not-allowed'
                      }`}
                      disabled={!powerUp.available}
                      onClick={() => powerUp.available && handleUsePowerUp(powerUp.id)}
                    >
                      {powerUp.available ? 'Utiliser' : 'Bientôt disponible'}
                    </button>
                  </div>
                  
                  {!powerUp.available && (
                    <div className="absolute inset-0 bg-slate-900/20 rounded-3xl flex items-center justify-center">
                      <div className="bg-slate-800/90 px-4 py-2 rounded-xl text-white/80 text-sm font-medium backdrop-blur-xl border border-white/20">
                        Bientôt disponible
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        );

      case 'stats':
        return (
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-white mb-4 flex items-center">
                <BarChart3 className="w-8 h-8 mr-3 text-green-400" />
                Statistiques détaillées de {currentAgent.name}
              </h2>
              <p className="text-white/70 text-lg">
                Analysez les performances et l'activité de votre agent
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Performance Chart */}
              <div className="relative bg-slate-800/40 backdrop-blur-xl rounded-3xl border border-slate-700/50 p-8 shadow-2xl overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-slate-700/20 via-transparent to-slate-600/20 rounded-3xl" />
                
                <div className="relative z-10">
                  <h3 className="text-xl font-bold text-white mb-6 flex items-center">
                    <TrendingUp className="w-6 h-6 mr-2 text-green-400" />
                    Performance globale
                  </h3>
                  
                  <div className="space-y-6">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-white/70">Satisfaction client</span>
                        <span className="text-white font-bold">{(parseFloat(currentAgent.stats.satisfaction) * 20).toFixed(0)}%</span>
                      </div>
                      <div className="w-full bg-slate-700/50 rounded-full h-3 overflow-hidden">
                        <div 
                          className="bg-gradient-to-r from-green-500 to-emerald-400 h-3 rounded-full transition-all duration-1000"
                          style={{ width: `${parseFloat(currentAgent.stats.satisfaction) * 20}%` }}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-white/70">Taux de résolution</span>
                        <span className="text-white font-bold">{currentAgent.stats.resolutionRate}</span>
                      </div>
                      <div className="w-full bg-slate-700/50 rounded-full h-3 overflow-hidden">
                        <div 
                          className="bg-gradient-to-r from-blue-500 to-cyan-400 h-3 rounded-full transition-all duration-1000"
                          style={{ width: currentAgent.stats.resolutionRate }}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-white/70">Temps de réponse</span>
                        <span className="text-white font-bold">{currentAgent.stats.responseTime}</span>
                      </div>
                      <div className="w-full bg-slate-700/50 rounded-full h-2 overflow-hidden">
                        <div className="bg-gradient-to-r from-orange-500 to-yellow-400 h-2 rounded-full w-3/4" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Activity Timeline */}
              <div className="relative bg-slate-800/40 backdrop-blur-xl rounded-3xl border border-slate-700/50 p-8 shadow-2xl overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-slate-700/20 via-transparent to-slate-600/20 rounded-3xl" />
                
                <div className="relative z-10">
                  <h3 className="text-xl font-bold text-white mb-6 flex items-center">
                    <Activity className="w-6 h-6 mr-2 text-purple-400" />
                    Activité récente
                  </h3>
                  
                  <div className="space-y-4">
                    {[
                      { time: 'Il y a 2 min', action: 'Conversation résolue', client: 'Marie D.', type: 'success' },
                      { time: 'Il y a 15 min', action: 'Nouveau ticket', client: 'Pierre M.', type: 'info' },
                      { time: 'Il y a 1h', action: 'Call terminé', client: 'Sophie L.', type: 'success' },
                      { time: 'Il y a 2h', action: 'Email envoyé', client: 'Thomas B.', type: 'info' },
                      { time: 'Il y a 3h', action: 'Chat initié', client: 'Julie K.', type: 'info' }
                    ].map((activity, index) => (
                      <div key={index} className="flex items-center space-x-4 p-4 bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 hover:bg-white/10 transition-all duration-300">
                        <div className={`w-3 h-3 rounded-full animate-pulse ${
                          activity.type === 'success' ? 'bg-green-400' : 'bg-blue-400'
                        }`} />
                        <div className="flex-1">
                          <div className="text-white font-medium text-sm">{activity.action}</div>
                          <div className="text-white/60 text-xs">{activity.client} • {activity.time}</div>
                        </div>
                        <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                          activity.type === 'success' 
                            ? 'bg-green-500/20 text-green-300 border border-green-500/30' 
                            : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                        }`}>
                          {activity.type === 'success' ? 'Résolu' : 'En cours'}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Global Stats */}
              <div className="md:col-span-2">
                <div className="relative bg-slate-800/40 backdrop-blur-xl rounded-3xl border border-slate-700/50 p-8 shadow-2xl overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-slate-700/20 via-transparent to-slate-600/20 rounded-3xl" />
                  
                  <div className="relative z-10">
                    <h3 className="text-xl font-bold text-white mb-6 flex items-center">
                      <Star className="w-6 h-6 mr-2 text-yellow-400" />
                      Métriques globales
                    </h3>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                      <div className="text-center p-4 bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10">
                        <div className="text-3xl font-bold text-white mb-2">{currentAgent.stats.conversations.toLocaleString()}</div>
                        <div className="text-white/60 text-sm">Conversations totales</div>
                      </div>
                      <div className="text-center p-4 bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10">
                        <div className="text-3xl font-bold text-green-400 mb-2">{currentAgent.stats.resolutionRate}</div>
                        <div className="text-white/60 text-sm">Taux de résolution</div>
                      </div>
                      <div className="text-center p-4 bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10">
                        <div className="text-3xl font-bold text-blue-400 mb-2">{currentAgent.stats.responseTime}</div>
                        <div className="text-white/60 text-sm">Temps de réponse</div>
                      </div>
                      <div className="text-center p-4 bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10">
                        <div className="text-3xl font-bold text-yellow-400 mb-2">{currentAgent.stats.satisfaction}</div>
                        <div className="text-white/60 text-sm">Note satisfaction</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'settings':
        return (
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-white mb-4 flex items-center">
                <Settings className="w-8 h-8 mr-3 text-purple-400" />
                Paramètres de {currentAgent.name}
              </h2>
              <p className="text-white/70 text-lg">
                Configurez et personnalisez votre agent selon vos besoins
              </p>
            </div>

            <div className="space-y-8">
              {/* Basic Settings */}
              <div className="relative bg-slate-800/40 backdrop-blur-xl rounded-3xl border border-slate-700/50 p-8 shadow-2xl overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-slate-700/20 via-transparent to-slate-600/20 rounded-3xl" />
                
                <div className="relative z-10">
                  <h3 className="text-xl font-bold text-white mb-6">Paramètres généraux</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-white/70 mb-2">Nom de l'agent</label>
                      <input
                        type="text"
                        defaultValue={currentAgent.name}
                        className="w-full px-4 py-3 bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl focus:border-white/40 focus:outline-none text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-white/70 mb-2">Rôle</label>
                      <input
                        type="text"
                        defaultValue={currentAgent.role}
                        className="w-full px-4 py-3 bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl focus:border-white/40 focus:outline-none text-white"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-white/70 mb-2">Description</label>
                      <textarea
                        defaultValue={currentAgent.description}
                        rows={3}
                        className="w-full px-4 py-3 bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl focus:border-white/40 focus:outline-none text-white resize-none"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Channels */}
              <div className="relative bg-slate-800/40 backdrop-blur-xl rounded-3xl border border-slate-700/50 p-8 shadow-2xl overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-slate-700/20 via-transparent to-slate-600/20 rounded-3xl" />
                
                <div className="relative z-10">
                  <h3 className="text-xl font-bold text-white mb-6 flex items-center">
                    <Globe className="w-6 h-6 mr-2 text-green-400" />
                    Canaux de communication
                  </h3>
                  
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {currentAgent.channels.map((channel: string, index: number) => (
                      <div key={index} className="flex items-center space-x-3 p-4 bg-white/10 backdrop-blur-xl rounded-2xl border border-white/20">
                        <div className="p-2 bg-green-500/20 rounded-lg">
                          {getChannelIcon(channel)}
                        </div>
                        <div>
                          <div className="text-white font-medium text-sm capitalize">{channel}</div>
                          <div className="text-green-400 text-xs">Actif</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Languages */}
              <div className="relative bg-slate-800/40 backdrop-blur-xl rounded-3xl border border-slate-700/50 p-8 shadow-2xl overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-slate-700/20 via-transparent to-slate-600/20 rounded-3xl" />
                
                <div className="relative z-10">
                  <h3 className="text-xl font-bold text-white mb-6 flex items-center">
                    <Globe className="w-6 h-6 mr-2 text-blue-400" />
                    Langues supportées
                  </h3>
                  
                  <div className="flex flex-wrap gap-3">
                    {currentAgent.languages.map((language: string, index: number) => (
                      <div key={index} className="px-4 py-2 bg-blue-500/20 text-blue-300 rounded-xl border border-blue-500/30 backdrop-blur-xl font-medium">
                        {language}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Advanced Settings */}
              <div className="relative bg-slate-800/40 backdrop-blur-xl rounded-3xl border border-slate-700/50 p-8 shadow-2xl overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-slate-700/20 via-transparent to-slate-600/20 rounded-3xl" />
                
                <div className="relative z-10">
                  <h3 className="text-xl font-bold text-white mb-6">Paramètres avancés</h3>
                  
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-white font-medium">Réponses automatiques</div>
                        <div className="text-white/60 text-sm">Activer les réponses automatiques pour les questions fréquentes</div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" className="sr-only peer" defaultChecked />
                        <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                      </label>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-white font-medium">Apprentissage continu</div>
                        <div className="text-white/60 text-sm">L'agent apprend de chaque interaction pour s'améliorer</div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" className="sr-only peer" defaultChecked />
                        <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                      </label>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-white font-medium">Escalade automatique</div>
                        <div className="text-white/60 text-sm">Transférer vers un humain si nécessaire</div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" className="sr-only peer" defaultChecked />
                        <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                      </label>
                    </div>
                  </div>
                </div>
              </div>

              {/* Save Button */}
              <div className="text-center">
                <button className="group relative overflow-hidden px-8 py-4 bg-blue-500/80 text-white rounded-2xl hover:bg-blue-500 transition-all duration-500 hover:scale-105 font-medium backdrop-blur-xl border border-blue-500/30 shadow-lg hover:shadow-blue-500/25">
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                  <div className="relative z-10 flex items-center space-x-2">
                    <Settings className="w-5 h-5" />
                    <span>Sauvegarder les paramètres</span>
                  </div>
                </button>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(59,130,246,0.1),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,rgba(147,51,234,0.1),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(148,163,184,0.03),transparent_50%)]" />
      
      {/* Header */}
      <div className="relative border-b border-slate-700/50 backdrop-blur-xl">
        <div className="absolute inset-0 bg-slate-800/20" />
        
        <div className="relative z-10 px-8 py-6">
          <AgentDetailHeader agent={currentAgent} onBack={onBack} />
        </div>
        
        {/* Bottom Glow Line */}
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-blue-500/50 to-transparent" />
      </div>

      {/* Content */}
      <div className="px-8 py-8">
        <AgentDetailTabs activeTab={activeTab} onTabChange={setActiveTab} />
        
        <div className="mt-8">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
};

export default AgentDetailView;