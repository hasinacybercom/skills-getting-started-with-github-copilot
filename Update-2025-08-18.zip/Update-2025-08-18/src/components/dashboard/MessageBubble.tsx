import React from 'react';
import { ChatMessage } from '../types/chat';
import { MediaDisplay } from './MediaDisplay';
import { Bot, User } from 'lucide-react';

interface MessageBubbleProps {
  message: ChatMessage;
  isAgent: boolean;
  currentAgentAvatar: '';
  currentAgentName: '';
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({ message, isAgent, currentAgentAvatar, currentAgentName}) => {
  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className={`flex mb-4 ${isAgent ? 'justify-start' : 'justify-end'}`}>
      <div className={`flex max-w-xs lg:max-w-md ${isAgent ? 'flex-row' : 'flex-row-reverse'}`}>
        {/* Avatar */}
        <div className={`flex-shrink-0 ${isAgent ? 'mr-3' : 'ml-3'}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
            isAgent 
              ? 'bg-blue-100 text-blue-600' 
              : 'bg-gray-100 text-gray-600'
          }`}>

            {isAgent && currentAgentAvatar && currentAgentName && (
              <img src={currentAgentAvatar} alt={currentAgentName} className="w-full h-full object-cover" />
            )}
            
            {isAgent ? '' : <User className="w-5 h-5" />}
          </div>
        </div>

        {/* Message Content */}
        <div className={`rounded-2xl px-4 py-2 shadow-sm ${
          isAgent 
            ? 'bg-white/10 backdrop-blur-xl text-white border border-white/20 rounded-tl-lg' 
            : 'bg-blue-500 text-white rounded-tr-lg'
        }`}>
          {/* Text Content */}
          {message.content && (
            <p className="text-sm leading-relaxed">{message.content}</p>
          )}

          {/* Media Content */}
          {message.media_type && message.media_url && (
            <div className="mb-2">
              <MediaDisplay 
                mediaType={message.media_type} 
                mediaUrl={message.media_url} 
                alt={`${message.media_type} from agent`}
              />
            </div>
          )}

          {/* Timestamp */}
          <div className={`text-xs mt-2 ${
            isAgent ? 'text-white/60' : 'text-blue-100'
          }`}>
            {formatTime(message.created_at)}
          </div>
        </div>
      </div>
    </div>
  );
};