import React, { useState } from 'react';
import { PlayCircle, ImageIcon, AlertCircle } from 'lucide-react';

interface MediaDisplayProps {
  mediaType: 'image' | 'video';
  mediaUrl: string;
  alt?: string;
}

export const MediaDisplay: React.FC<MediaDisplayProps> = ({ 
  mediaType, 
  mediaUrl, 
  alt = 'Media content' 
}) => {
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);

  const handleLoad = () => {
    setIsLoading(false);
  };

  const handleError = () => {
    setIsLoading(false);
    setHasError(true);
  };

  if (hasError) {
    return (
      <div className="flex items-center justify-center w-full h-32 bg-gray-100 rounded-lg border-2 border-dashed border-gray-300">
        <div className="text-center text-gray-500">
          <AlertCircle className="w-8 h-8 mx-auto mb-2" />
          <p className="text-sm">Failed to load {mediaType}</p>
        </div>
      </div>
    );
  }

  if (mediaType === 'image') {
    return (
      <div className="relative max-w-sm">
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-100 rounded-lg animate-pulse">
            <ImageIcon className="w-8 h-8 text-gray-400" />
          </div>
        )}
        <img
          src={mediaUrl}
          alt={alt}
          className={`rounded-lg shadow-sm max-w-full h-auto transition-opacity duration-200 ${
            isLoading ? 'opacity-0' : 'opacity-100'
          }`}
          onLoad={handleLoad}
          onError={handleError}
          style={{ maxHeight: '300px' }}
        />
      </div>
    );
  }

  if (mediaType === 'video') {
    return (
      <div className="relative max-w-sm">
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-100 rounded-lg animate-pulse">
            <PlayCircle className="w-8 h-8 text-gray-400" />
          </div>
        )}
        <video
          src={mediaUrl}
          controls
          className={`rounded-lg shadow-sm max-w-full h-auto transition-opacity duration-200 ${
            isLoading ? 'opacity-0' : 'opacity-100'
          }`}
          onLoadedData={handleLoad}
          onError={handleError}
          style={{ maxHeight: '300px' }}
          preload="metadata"
        >
          Your browser does not support the video tag.
        </video>
      </div>
    );
  }

  return null;
};