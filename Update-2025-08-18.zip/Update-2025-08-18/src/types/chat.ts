export interface ChatMessage {
  id: string;
  company_id: string;
  agent_id: string;
  conversation_id: string;
  sender_type: 'agent' | 'user';
  content: string;
  media_type?: 'image' | 'video' | null;
  media_url?: string | null;
  created_at: string;
}

export interface Agent {
  id: string;
  name: string;
  avatar?: string;
  status: 'online' | 'offline' | 'busy';
}

export interface ChatProps {
  agent: Agent;
  messages: ChatMessage[];
  onSendMessage?: (message: string) => void;
}